use std::{
    fs::{self, File},
    io::{BufReader, Read, Seek, SeekFrom},
    path::{Path, PathBuf},
    sync::{
        atomic::{AtomicBool, Ordering},
        mpsc::{self, Receiver, TryRecvError},
        Arc,
    },
    time::{Duration, Instant},
};

use eframe::egui::{
    self, Align2, Color32, FontFamily, FontId, Rect, RichText, Sense, Stroke, Vec2,
};
use rodio::{Decoder, OutputStream, Sink, Source};
use walkdir::WalkDir;

// ---------------------------------------------------------------------------
// Theme
// ---------------------------------------------------------------------------

static LIGHT_MODE: AtomicBool = AtomicBool::new(false);

/// Colour of the application name.
const TITLE_COLOR: Color32 = Color32::from_rgb(91, 163, 136);
/// Colour of the settings (gear) icon.
const GEAR_COLOR: Color32 = Color32::from_rgb(71, 91, 83);

/// Colours shared by every custom-painted part of the UI.
#[derive(Clone, Copy)]
struct Palette {
    bg: Color32,
    toolbar_bg: Color32,
    player_bg: Color32,
    header_bg: Color32,
    row_bg: Color32,
    row_alt_bg: Color32,
    row_hover: Color32,
    selected_bg: Color32,
    selected_hover: Color32,
    selected_text: Color32,
    border: Color32,
    text: Color32,
    muted: Color32,
    dim: Color32,
    accent: Color32,
    wave: Color32,
    wave_played: Color32,
    playhead: Color32,
    error: Color32,
    wave_bg: Color32,
    wave_zero: Color32,
    scrub_hint: Color32,
    extreme_bg: Color32,
    widget_bg: Color32,
    widget_weak: Color32,
    widget_hover_bg: Color32,
    widget_hover_weak: Color32,
    widget_active_bg: Color32,
    widget_active_weak: Color32,
}

impl Palette {
    const DARK: Self = Self {
        bg: Color32::from_rgb(14, 16, 20),
        toolbar_bg: Color32::from_rgb(18, 20, 26),
        player_bg: Color32::from_rgb(17, 20, 25),
        header_bg: Color32::from_rgb(21, 24, 30),
        row_bg: Color32::from_rgb(16, 18, 23),
        row_alt_bg: Color32::from_rgb(19, 22, 28),
        row_hover: Color32::from_rgb(29, 34, 43),
        selected_bg: Color32::from_rgb(91, 163, 136),
        selected_hover: Color32::from_rgb(107, 180, 153),
        selected_text: Color32::from_rgb(9, 32, 24),
        border: Color32::from_rgb(36, 41, 50),
        text: Color32::from_rgb(229, 233, 240),
        muted: Color32::from_rgb(133, 142, 158),
        dim: Color32::from_rgb(92, 101, 116),
        accent: Color32::from_rgb(91, 163, 136),
        wave: Color32::from_rgb(50, 96, 80),
        wave_played: Color32::from_rgb(91, 163, 136),
        playhead: Color32::from_rgb(61, 242, 174),
        error: Color32::from_rgb(245, 110, 110),
        wave_bg: Color32::from_rgb(11, 13, 17),
        wave_zero: Color32::from_rgb(34, 39, 48),
        scrub_hint: Color32::from_rgb(96, 106, 126),
        extreme_bg: Color32::from_rgb(10, 12, 15),
        widget_bg: Color32::from_rgb(31, 36, 45),
        widget_weak: Color32::from_rgb(27, 31, 39),
        widget_hover_bg: Color32::from_rgb(39, 46, 58),
        widget_hover_weak: Color32::from_rgb(35, 41, 52),
        widget_active_bg: Color32::from_rgb(45, 53, 67),
        widget_active_weak: Color32::from_rgb(41, 48, 61),
    };

    const LIGHT: Self = Self {
        bg: Color32::from_rgb(242, 244, 248),
        toolbar_bg: Color32::from_rgb(250, 251, 253),
        player_bg: Color32::from_rgb(250, 251, 253),
        header_bg: Color32::from_rgb(232, 236, 242),
        row_bg: Color32::from_rgb(255, 255, 255),
        row_alt_bg: Color32::from_rgb(247, 249, 252),
        row_hover: Color32::from_rgb(235, 240, 248),
        selected_bg: Color32::from_rgb(91, 163, 136),
        selected_hover: Color32::from_rgb(78, 147, 120),
        selected_text: Color32::from_rgb(9, 32, 24),
        border: Color32::from_rgb(212, 217, 226),
        text: Color32::from_rgb(26, 31, 40),
        muted: Color32::from_rgb(96, 106, 122),
        dim: Color32::from_rgb(142, 150, 164),
        accent: Color32::from_rgb(91, 163, 136),
        wave: Color32::from_rgb(157, 202, 187),
        wave_played: Color32::from_rgb(91, 163, 136),
        playhead: Color32::from_rgb(61, 242, 174),
        error: Color32::from_rgb(185, 45, 45),
        wave_bg: Color32::from_rgb(252, 253, 255),
        wave_zero: Color32::from_rgb(214, 220, 229),
        scrub_hint: Color32::from_rgb(150, 160, 178),
        extreme_bg: Color32::from_rgb(248, 249, 251),
        widget_bg: Color32::from_rgb(249, 250, 252),
        widget_weak: Color32::from_rgb(237, 240, 245),
        widget_hover_bg: Color32::from_rgb(240, 243, 248),
        widget_hover_weak: Color32::from_rgb(227, 232, 240),
        widget_active_bg: Color32::from_rgb(235, 240, 248),
        widget_active_weak: Color32::from_rgb(216, 224, 238),
    };
}

fn theme() -> Palette {
    if LIGHT_MODE.load(Ordering::Relaxed) {
        Palette::LIGHT
    } else {
        Palette::DARK
    }
}

const HELP_ITEMS: &[(&str, &str)] = &[
    (
        "Add folder...",
        "Recursively scans the selected folder and all of its sub-folders for supported sounds.",
    ),
    (
        "Add files...",
        "Adds individual sound files that you pick from disk.",
    ),
    (
        "Search",
        "The magnifier button next to Add files... opens a search box. Type part of a sound name; only matching sounds stay visible. Press Escape, click the small X, or click the magnifier again to clear the search and show the full list.",
    ),
    (
        "Drag and drop",
        "Drop a folder or one or more sound files anywhere on the window to import them.",
    ),
    (
        "Name, Bit rate, Frequency",
        "Each row is one sound. Bit rate is shown in kbps and frequency (sample rate) in kHz.",
    ),
    (
        "Open link (FILE column)",
        "Shows the folder that contains the sound in your file manager, with the file selected. It does not start playback.",
    ),
    (
        "Select and play",
        "Click a row to select that sound and start playing it. The selected row is highlighted in green.",
    ),
    (
        "Waveform",
        "The bottom panel draws the waveform of the selected sound.",
    ),
    (
        "Playhead and scrubbing",
        "The large mint-green playhead moves while the sound plays. Click or drag anywhere on the waveform to move it; playback jumps to that position, or starts there when the sound is stopped.",
    ),
    (
        "Play, Restart, Stop",
        "Play / Restart starts the sound again from the beginning. Stop stops playback. You can still move the playhead afterwards and press Play to continue from there.",
    ),
    (
        "Volume",
        "The Volume slider in the player bar sets the playback level. It applies immediately while a sound is playing and to every sound you play afterwards.",
    ),
    (
        "Save selection...",
        "Opens a native save dialog and writes the selected In/Out span as a WAV excerpt. No ffmpeg is required.",
    ),
    (
        "Deselect, Clear selection, Clear list",
        "Deselect removes the current selection. Clear selection stops playback and deselects everything. Clear list removes every loaded sound.",
    ),
    (
        "In / Out point buttons",
        "In earlier, In later, Out earlier and Out later move the selection endpoints by 0.5 seconds without dragging.",
    ),
    (
        "Importing sounds",
        "While importing, a floating window shows how many sounds are loaded, how many are still to load, how many were skipped, and lets you cancel the import.",
    ),
    (
        "Restoring the list",
        "The sounds you load are remembered between runs. When Sound Finder starts again without a folder argument, the same list is loaded automatically; files that no longer exist are skipped.",
    ),
    (
        "Settings",
        "The gear button to the left of the application name switches between Dark mode and Light mode, and opens this Help window and the About window.",
    ),
    ("Supported formats", "WAV, MP3, FLAC, OGG and OGA."),
];

const ROW_HEIGHT: f32 = 36.0;
const HEADER_HEIGHT: f32 = 30.0;
const BITRATE_WIDTH: f32 = 112.0;
const FREQUENCY_WIDTH: f32 = 118.0;
const LINK_WIDTH: f32 = 64.0;
const WAVEFORM_POINTS: usize = 1400;
const AUDIO_EXTENSIONS: [&str; 5] = ["wav", "mp3", "flac", "ogg", "oga"];

// ---------------------------------------------------------------------------
// Data
// ---------------------------------------------------------------------------

struct SoundEntry {
    name: String,
    path: PathBuf,
    sample_rate: u32,
    channels: u16,
    bitrate_kbps: u32,
    duration_secs: f32,
    waveform: Vec<f32>,
}

impl SoundEntry {
    fn bitrate_text(&self) -> String {
        if self.bitrate_kbps == 0 {
            "-".to_owned()
        } else {
            format!("{} kbps", self.bitrate_kbps)
        }
    }

    fn frequency_text(&self) -> String {
        if self.sample_rate == 0 {
            "-".to_owned()
        } else {
            format!("{:.1} kHz", self.sample_rate as f32 / 1000.0)
        }
    }

    fn details_text(&self) -> String {
        format!(
            "{}  |  {}  |  {}  |  {} ch",
            self.bitrate_text(),
            self.frequency_text(),
            format_time(self.duration_secs),
            self.channels
        )
    }
}

enum LoadMsg {
    Done(SoundEntry),
    Failed,
    Finished,
}

#[derive(Clone, Copy)]
struct RangeState {
    active: bool,
    selecting: bool,
    dragging: bool,
    range_start: f32,
    range_end: f32,
    drag_in: f32,
    drag_out: f32,
}

// ---------------------------------------------------------------------------
// App
// ---------------------------------------------------------------------------

struct SoundFinderApp {
    library: Vec<SoundEntry>,
    selected: Option<usize>,
    playing: Option<usize>,
    volume: f32,
    playhead: f32,
    range: RangeState,
    play_started: Option<Instant>,
    sink: Option<Sink>,
    // Kept alive for as long as the app lives.
    _stream: Option<OutputStream>,
    load_rx: Option<Receiver<LoadMsg>>,
    load_total: usize,
    load_done: usize,
    load_failed: usize,
    loading: bool,
    cancel: Arc<AtomicBool>,
    status: String,
    status_is_error: bool,
    titlebar_styled: bool,
    light_mode: bool,
    show_settings: bool,
    show_help: bool,
    show_about: bool,
    search_open: bool,
    search_query: String,
    search_focus: bool,
    text_input_focus: bool,
}

impl SoundFinderApp {
    fn new(initial: Vec<PathBuf>) -> Self {
        let (stream, sink) = match OutputStream::try_default() {
            Ok((stream, handle)) => (Some(stream), Sink::try_new(&handle).ok()),
            Err(err) => {
                eprintln!("Sound Finder: audio output unavailable: {err}");
                (None, None)
            }
        };

        let mut app = Self {
            library: Vec::new(),
            selected: None,
            playing: None,
            volume: 1.0,
            playhead: 0.0,
            range: RangeState {
                active: false,
                selecting: false,
                dragging: false,
                range_start: 0.0,
                range_end: 0.0,
                drag_in: 0.0,
                drag_out: 0.0,
            },
            play_started: None,
            sink,
            _stream: stream,
            load_rx: None,
            load_total: 0,
            load_done: 0,
            load_failed: 0,
            loading: false,
            cancel: Arc::new(AtomicBool::new(false)),
            status: "Choose a folder to scan it recursively for sounds.".to_owned(),
            status_is_error: false,
            titlebar_styled: false,
            light_mode: false,
            show_settings: false,
            show_help: false,
            show_about: false,
            search_open: false,
            search_query: String::new(),
            search_focus: false,
            text_input_focus: false,
        };

        if !initial.is_empty() {
            app.load_paths(initial);
        } else {
            let restored = load_saved_library();
            if !restored.is_empty() {
                app.load_paths(restored);
            }
        }
        app.apply_volume();
        app
    }

    // -- loading ------------------------------------------------------------

    fn add_folder_dialog(&mut self) {
        if let Some(folder) = rfd::FileDialog::new()
            .set_title("Choose a folder containing sounds")
            .pick_folder()
        {
            let paths = collect_audio_files(&folder);
            if paths.is_empty() {
                self.set_status("No supported audio files found in that folder.", true);
            } else {
                self.load_paths(paths);
            }
        }
    }

    fn add_files_dialog(&mut self) {
        if let Some(paths) = rfd::FileDialog::new()
            .set_title("Choose sound files")
            .add_filter("Audio", &AUDIO_EXTENSIONS)
            .pick_files()
        {
            self.load_paths(paths);
        }
    }

    fn load_paths(&mut self, paths: Vec<PathBuf>) {
        if self.loading {
            return;
        }

        let mut known: std::collections::HashSet<String> = self
            .library
            .iter()
            .map(|entry| path_key(&entry.path))
            .collect();

        let mut new_paths = Vec::new();
        for path in paths {
            if !is_audio_file(&path) {
                continue;
            }
            if known.insert(path_key(&path)) {
                new_paths.push(path);
            }
        }

        if new_paths.is_empty() {
            self.set_status("No new sounds to load.", false);
            return;
        }

        let total = new_paths.len();
        let (tx, rx) = mpsc::channel();
        let cancel = Arc::new(AtomicBool::new(false));
        let worker_cancel = Arc::clone(&cancel);

        self.load_rx = Some(rx);
        self.load_total = total;
        self.load_done = 0;
        self.load_failed = 0;
        self.loading = true;
        self.cancel = cancel;
        self.status = format!("Loading 0 / {total} sounds...");
        self.status_is_error = false;

        std::thread::spawn(move || {
            for path in new_paths {
                if worker_cancel.load(Ordering::Relaxed) {
                    break;
                }
                match decode_entry(&path) {
                    Ok(entry) => {
                        if tx.send(LoadMsg::Done(entry)).is_err() {
                            break;
                        }
                    }
                    Err(err) => {
                        eprintln!(
                            "Sound Finder: skipping {}: {err}",
                            path.display()
                        );
                        if tx.send(LoadMsg::Failed).is_err() {
                            break;
                        }
                    }
                }
            }
            let _ = tx.send(LoadMsg::Finished);
        });
    }

    fn poll_loading(&mut self) {
        let Some(rx) = self.load_rx.take() else {
            return;
        };

        let mut finished = false;
        loop {
            match rx.try_recv() {
                Ok(LoadMsg::Done(entry)) => {
                    self.library.push(entry);
                    self.load_done += 1;
                }
                Ok(LoadMsg::Failed) => {
                    self.load_done += 1;
                    self.load_failed += 1;
                }
                Ok(LoadMsg::Finished) => {
                    finished = true;
                }
                Err(TryRecvError::Empty) => break,
                Err(TryRecvError::Disconnected) => {
                    finished = true;
                    break;
                }
            }
        }

        if finished || (self.load_total > 0 && self.load_done >= self.load_total) {
            self.loading = false;
            self.load_rx = None;
            let loaded = self.load_done.saturating_sub(self.load_failed);
            let failed = self.load_failed;
            let message = if failed > 0 {
                format!("Loaded {loaded} sound(s); {failed} file(s) could not be decoded.")
            } else {
                format!("Loaded {loaded} sound(s).")
            };
            self.set_status(&message, failed > 0);
        } else {
            self.load_rx = Some(rx);
            self.status = format!(
                "Loading {} / {} sounds...{}",
                self.load_done,
                self.load_total,
                if self.load_failed > 0 {
                    format!("  ({} skipped)", self.load_failed)
                } else {
                    String::new()
                }
            );
            self.status_is_error = false;
        }

        if finished {
            self.save_library();
        }
    }

    /// Writes the paths of the loaded sounds so the next launch can restore them.
    fn save_library(&self) {
        let Some(path) = library_state_path() else {
            return;
        };
        if let Some(parent) = path.parent() {
            let _ = fs::create_dir_all(parent);
        }

        let mut text = String::new();
        for entry in &self.library {
            let stored = fs::canonicalize(&entry.path).unwrap_or_else(|_| entry.path.to_path_buf());
            text.push_str(&stored.to_string_lossy());
            text.push('\n');
        }

        if let Err(err) = fs::write(&path, text) {
            eprintln!(
                "Sound Finder: could not save the sound list to {}: {err}",
                path.display()
            );
        }
    }

    fn cancel_loading(&mut self) {
        self.cancel.store(true, Ordering::Relaxed);
        self.load_rx = None;
        self.loading = false;
        self.cancel = Arc::new(AtomicBool::new(false));
        self.save_library();
        self.set_status("Loading cancelled.", false);
    }

    // -- playback -----------------------------------------------------------

    fn select_and_play(&mut self, index: usize) {
        if index >= self.library.len() {
            return;
        }
        if self.selected != Some(index) {
            self.clear_range();
        }
        self.selected = Some(index);
        self.start_playback(index);
    }

    /// Applies the current volume to the audio sink.
    fn apply_volume(&self) {
        if let Some(sink) = &self.sink {
            sink.set_volume(self.volume.clamp(0.0, 1.0));
        }
    }

    fn start_playback(&mut self, index: usize) {
        let start = if self.range.active {
            self.range.range_start
        } else {
            0.0
        };
        self.start_playback_at(index, start);
    }

    /// Starts or restarts `index` at `start` seconds.
    fn start_playback_at(&mut self, index: usize, start: f32) {
        let Some(sink) = self.sink.as_ref() else {
            self.set_status("Audio output is unavailable on this machine.", true);
            return;
        };
        sink.set_volume(self.volume.clamp(0.0, 1.0));
        let Some(entry) = self.library.get(index) else {
            return;
        };
        let duration = entry.duration_secs.max(0.0);
        let start = if self.range.active {
            start.clamp(self.range.range_start, self.range.range_end)
        } else if duration > 0.0 {
            start.clamp(0.0, duration)
        } else {
            0.0
        };

        sink.stop();
        match File::open(&entry.path)
            .map_err(|err| err.to_string())
            .and_then(|file| {
                Decoder::new(BufReader::new(file)).map_err(|err| err.to_string())
            }) {
            Ok(source) => {
                sink.append(source.skip_duration(Duration::from_secs_f32(start)));
                sink.play();
                self.playing = Some(index);
                self.play_started =
                    Some(Instant::now().checked_sub(Duration::from_secs_f32(start))
                        .unwrap_or_else(Instant::now));
                self.playhead = start;
                self.status = if start > 0.01 {
                    format!("Playing {} from {}", entry.name, format_time(start))
                } else {
                    format!("Playing {}", entry.name)
                };
                self.status_is_error = false;
            }
            Err(err) => {
                self.playing = None;
                self.play_started = None;
                self.playhead = 0.0;
                self.set_status(&format!("Could not play {}: {err}", entry.name), true);
            }
        }
    }

    /// Moves the playhead of `index` to `time` seconds and keeps the audio in sync.
    fn seek_to(&mut self, index: usize, time: f32) {
        let Some(entry) = self.library.get(index) else {
            return;
        };
        let duration = entry.duration_secs.max(0.001);
        let mut time = time.clamp(0.0, duration);

        if self.range.active {
            time = time.clamp(self.range.range_start, self.range.range_end);
        }

        self.playhead = time;

        if self.playing != Some(index) {
            // Not currently playing: start the sound at the requested position.
            self.start_playback_at(index, time);
            return;
        }

        let seek_result = self
            .sink
            .as_ref()
            .map(|sink| sink.try_seek(Duration::from_secs_f32(time)));
        match seek_result {
            Some(Ok(())) => {
                self.play_started = Some(
                    Instant::now()
                        .checked_sub(Duration::from_secs_f32(time))
                        .unwrap_or_else(Instant::now),
                );
            }
            _ => {
                // A decoder that cannot seek: restart from the requested position.
                self.start_playback_at(index, time);
            }
        }
    }

    fn stop_playback(&mut self) {
        if let Some(sink) = self.sink.as_ref() {
            sink.stop();
        }
        self.playing = None;
        self.play_started = None;
        self.playhead = if self.range.active {
            self.range.range_start
        } else {
            0.0
        };
    }

    fn clear_range(&mut self) {
        self.range.active = false;
        self.range.selecting = false;
        self.range.dragging = false;
        self.range.range_start = 0.0;
        self.range.range_end = 0.0;
        self.range.drag_in = 0.0;
        self.range.drag_out = 0.0;
    }

    /// Moves the In point of the active selection by `delta` seconds.
    fn move_range_in(&mut self, delta: f32) {
        let Some(index) = self.selected else {
            return;
        };
        let Some(entry) = self.library.get(index) else {
            return;
        };
        let duration = entry.duration_secs.max(0.0);
        if !self.range.active || duration <= 0.0 {
            return;
        }

        let min_gap = 0.02;
        let max_start = self.range.range_end - min_gap;
        if max_start < 0.0 {
            return;
        }

        let start = (self.range.range_start + delta).clamp(0.0, max_start);
        self.range.range_start = start;
        self.playhead = self.playhead.clamp(
            self.range.range_start,
            self.range.range_end
        );
        if self.playing == Some(index) {
            self.seek_to(index, self.playhead);
        }
    }

    /// Moves the Out point of the active selection by `delta` seconds.
    fn move_range_out(&mut self, delta: f32) {
        let Some(index) = self.selected else {
            return;
        };
        let Some(entry) = self.library.get(index) else {
            return;
        };
        let duration = entry.duration_secs.max(0.0);
        if !self.range.active || duration <= 0.0 {
            return;
        }

        let min_gap = 0.02;
        let min_end = self.range.range_start + min_gap;
        if min_end > duration {
            return;
        }

        let end = (self.range.range_end + delta).clamp(min_end, duration);
        self.range.range_end = end;
        self.playhead = self.playhead.clamp(
            self.range.range_start,
            self.range.range_end
        );
        if self.playing == Some(index) {
            self.seek_to(index, self.playhead);
        }
    }

    fn clear_selection(&mut self) {
        self.stop_playback();
        self.clear_range();
        self.selected = None;
        self.set_status("Selection cleared.", false);
    }

    /// Saves the current In/Out selection as a WAV excerpt.
    fn export_selection(&mut self) {
        let Some(index) = self.selected else {
            self.set_status("Select a sound first.", true);
            return;
        };

        if !self.range.active {
            self.set_status("Select an In/Out range before saving.", true);
            return;
        }

        let Some(entry) = self.library.get(index) else {
            self.selected = None;
            self.set_status("The selected sound is no longer available.", true);
            return;
        };

        let duration = entry.duration_secs.max(0.0);
        let start = self.range.range_start.clamp(0.0, duration);
        let end = self.range.range_end.clamp(0.0, duration);
        if end - start < 0.02 {
            self.set_status("The selected range is too short to save.", true);
            return;
        }

        let Some(parent) = entry.path.parent() else {
            self.set_status("Could not find the folder for this sound.", true);
            return;
        };

        let suggested = format!("{}_selection.wav", entry.name);
        let Some(output) = rfd::FileDialog::new()
            .set_title("Save the selected excerpt")
            .set_file_name(&suggested)
            .set_directory(&parent)
            .save_file() else {
            self.set_status("Save cancelled.", false);
            return;
        };

        if path_key(&output) == path_key(&entry.path) {
            self.set_status("Choose a different file name.", true);
            return;
        }

        let channels = entry.channels as usize;
        let target_samples =
            ((end - start) * entry.sample_rate as f32).round() as usize * channels;

        match File::open(&entry.path)
            .map_err(|err| err.to_string())
            .and_then(|file| {
                Decoder::new(BufReader::new(file)).map_err(|err| err.to_string())
            }) {
            Ok(source) => {
                let source = source.skip_duration(Duration::from_secs_f32(start));
                let mut samples = Vec::new();
                let mut count = 0_usize;

                for sample in source {
                    if count >= target_samples {
                        break;
                    }
                    let raw = (sample as i32) & 0xFFFF;
                    samples.push((raw & 0xFF) as u8);
                    samples.push(((raw >> 8) & 0xFF) as u8);
                    count += 1;
                }

                let data_size = samples.len() as u32;
                let mut bytes = Vec::new();

                append_ascii(&mut bytes, "RIFF");
                append_u32_le(&mut bytes, 36 + data_size);
                append_ascii(&mut bytes, "WAVE");

                append_ascii(&mut bytes, "fmt ");
                append_u32_le(&mut bytes, 16);
                append_u16_le(&mut bytes, 1);
                append_u16_le(&mut bytes, entry.channels);
                append_u32_le(&mut bytes, entry.sample_rate);
                append_u32_le(
                    &mut bytes,
                    entry.sample_rate * entry.channels as u32 * 2,
                );
                append_u16_le(&mut bytes, entry.channels as u16 * 2);
                append_u16_le(&mut bytes, 16);

                append_ascii(&mut bytes, "data");
                append_u32_le(&mut bytes, data_size);
                for byte in samples {
                    bytes.push(byte);
                }

                if let Err(err) = fs::write(&output, &bytes) {
                    self.set_status(
                        &format!("Could not save the selection: {}", err),
                        true,
                    );
                } else {
                    self.set_status(
                        &format!("Saved selection to {}", output.display()),
                        false,
                    );
                }
            }
            Err(err) => {
                self.set_status(
                    &format!("Could not read {}: {}", entry.name, err),
                    true,
                );
            }
        }
    }

    fn clear_library(&mut self) {
        if self.loading {
            self.cancel_loading();
        }
        self.stop_playback();
        self.clear_range();
        self.selected = None;
        self.library.clear();
        self.search_query.clear();
        self.save_library();
        self.set_status("All sounds removed.", false);
    }

    fn tick(&mut self) {
        let Some(index) = self.playing else {
            return;
        };
        let Some(entry) = self.library.get(index) else {
            self.stop_playback();
            return;
        };

        let duration = entry.duration_secs;
        let elapsed = self
            .play_started
            .map(|start| start.elapsed().as_secs_f32())
            .unwrap_or(0.0);
        let ended = self
            .sink
            .as_ref()
            .map(|sink| sink.empty())
            .unwrap_or(true);

        self.playhead = elapsed.min(duration.max(0.0));

        if self.range.active && self.playhead >= self.range.range_end - 0.01 {
            self.start_playback_at(index, self.range.range_start);
            return;
        }

        if ended || elapsed >= duration.max(0.001) {
            let start = if self.range.active {
                self.range.range_start
            } else {
                0.0
            };
            self.start_playback_at(index, start);
            return;
        }
    }

    fn set_status(&mut self, message: &str, is_error: bool) {
        self.status = message.to_owned();
        self.status_is_error = is_error;
    }

    /// Number of sounds that currently match the search query.
    fn matching_count(&self) -> usize {
        let query = self.search_query.trim().to_lowercase();
        if query.is_empty() {
            self.library.len()
        } else {
            self.library
                .iter()
                .filter(|entry| entry.name.to_lowercase().contains(&query))
                .count()
        }
    }

    // -- UI -----------------------------------------------------------------

    fn toolbar_ui(&mut self, ui: &mut egui::Ui) {
        ui.horizontal(|ui| {
            if gear_button(ui).clicked() {
                self.show_settings = true;
            }
            ui.add_space(2.0);
            ui.label(
                RichText::new("Sound Finder")
                    .font(FontId::new(30.0, title_family()))
                    .color(TITLE_COLOR),
            );
            ui.add_space(14.0);

            if ui
                .add_enabled(!self.loading, egui::Button::new("Add folder..."))
                .on_hover_text("Scan a folder and all of its sub-folders")
                .clicked()
            {
                self.add_folder_dialog();
            }
            if ui
                .add_enabled(!self.loading, egui::Button::new("Add files..."))
                .clicked()
            {
                self.add_files_dialog();
            }

            if search_button(ui, self.search_open).clicked() {
                self.search_open = !self.search_open;
                if self.search_open {
                    self.search_focus = true;
                } else {
                    self.search_query.clear();
                }
            }
            self.text_input_focus = false;
            if self.search_open {
                let response = ui.add(
                    egui::TextEdit::singleline(&mut self.search_query)
                        .hint_text("Search by name...")
                        .desired_width(190.0),
                );
                if self.search_focus {
                    response.request_focus();
                    self.search_focus = false;
                }
                self.text_input_focus = response.has_focus();
                if response.has_focus()
                    && ui.input(|i| i.key_pressed(egui::Key::Escape))
                {
                    self.search_query.clear();
                    self.search_open = false;
                }
                if search_clear_button(ui, !self.search_query.is_empty()).clicked()
                    && !self.search_query.is_empty()
                {
                    self.search_query.clear();
                    self.search_focus = true;
                }
            }

            if self.loading {
                ui.add_space(6.0);
                ui.add(egui::Spinner::new().size(14.0));
            }

            ui.with_layout(
                egui::Layout::right_to_left(egui::Align::Center),
                |ui| {
                    if ui
                        .add_enabled(
                            self.selected.is_some(),
                            egui::Button::new("Clear selection"),
                        )
                        .on_hover_text("Deselect every sound and stop playback")
                        .clicked()
                    {
                        self.clear_selection();
                    }

                    if ui
                        .add_enabled(
                            !self.library.is_empty() || self.loading,
                            egui::Button::new("Clear list"),
                        )
                        .on_hover_text("Remove every loaded sound")
                        .clicked()
                    {
                        self.clear_library();
                    }

                    let count = self.library.len();
                    let matching = self.matching_count();
                    let searching = !self.search_query.trim().is_empty();
                    ui.label(
                        RichText::new(if searching {
                            format!("{matching} of {count} sounds")
                        } else {
                            format!(
                                "{count} sound{}",
                                if count == 1 { "" } else { "s" }
                            )
                        })
                        .size(12.5)
                        .color(theme().muted),
                    );
                },
            );
        });

        ui.add_space(3.0);
        ui.label(
            RichText::new(&self.status)
                .size(11.5)
                .color(if self.status_is_error { theme().error } else { theme().muted }),
        );
    }

    fn table_ui(&mut self, ui: &mut egui::Ui) {
        ui.add_space(12.0);

        if self.library.is_empty() {
            self.empty_state_ui(ui);
            return;
        }

        let query = self.search_query.trim().to_lowercase();
        let visible: Vec<usize> = if query.is_empty() {
            (0..self.library.len()).collect()
        } else {
            self.library
                .iter()
                .enumerate()
                .filter(|(_, entry)| entry.name.to_lowercase().contains(&query))
                .map(|(index, _)| index)
                .collect()
        };

        if visible.is_empty() {
            self.no_matches_ui(ui);
            return;
        }

        let width = ui.available_width();
        draw_header(ui, width);

        let mut clicked_row = None;
        let mut clicked_link = None;
        let library = &self.library;
        let selected = self.selected;
        let playing = self.playing;

        egui::ScrollArea::vertical()
            .auto_shrink([false, false])
            .show_rows(ui, ROW_HEIGHT, visible.len(), |ui, range| {
                for row in range {
                    let index = visible[row];
                    let entry = &library[index];
                    let is_selected = selected == Some(index);
                    let is_playing = playing == Some(index);
                    let (rect, response) = ui.allocate_exact_size(
                        Vec2::new(ui.available_width(), ROW_HEIGHT),
                        Sense::click(),
                    );

                    if ui.is_rect_visible(rect) {
                        let response = response
                            .on_hover_cursor(egui::CursorIcon::PointingHand)
                            .on_hover_text(format!(
                                "{}\n{}",
                                entry.name,
                                entry.path.display()
                            ));

                        let background = if is_selected {
                            if response.hovered() {
                                theme().selected_hover
                            } else {
                                theme().selected_bg
                            }
                        } else if response.hovered() {
                            theme().row_hover
                        } else if row % 2 == 0 {
                            theme().row_bg
                        } else {
                            theme().row_alt_bg
                        };

                        let painter = ui.painter();
                        painter.rect_filled(rect, 0.0, background);

                        if is_selected {
                            painter.rect_filled(
                                Rect::from_min_size(
                                    rect.left_top(),
                                    Vec2::new(3.0, rect.height()),
                                ),
                                0.0,
                                theme().selected_text,
                            );
                        }

                        painter.line_segment(
                            [
                                egui::pos2(rect.left(), rect.bottom()),
                                egui::pos2(rect.right(), rect.bottom()),
                            ],
                            Stroke::new(1.0_f32, theme().border),
                        );

                        let columns = Columns::new(rect.width());
                        let name_color = if is_selected {
                            theme().selected_text
                        } else {
                            theme().text
                        };
                        let meta_color = if is_selected {
                            theme().selected_text
                        } else {
                            theme().muted
                        };
                        let link_area = Rect::from_min_max(
                            egui::pos2(rect.left() + columns.link_x - 2.0, rect.top()),
                            egui::pos2(rect.right() - 6.0, rect.bottom()),
                        );
                        let link_hovered = response
                            .hover_pos()
                            .map(|pos| link_area.contains(pos))
                            .unwrap_or(false);
                        let link_color = if is_selected {
                            theme().selected_text
                        } else if link_hovered {
                            theme().text
                        } else {
                            theme().accent
                        };

                        let name_clip = Rect::from_min_max(
                            egui::pos2(rect.left() + 14.0, rect.top()),
                            egui::pos2(
                                rect.left() + columns.bitrate_x - 8.0,
                                rect.bottom(),
                            ),
                        );
                        let name_painter = painter.with_clip_rect(name_clip);

                        if is_playing {
                            let y = rect.center().y;
                            painter.circle_filled(
                                egui::pos2(rect.left() + 7.0, y),
                                2.5,
                                if is_selected {
                                    theme().selected_text
                                } else {
                                    theme().accent
                                },
                            );
                        }

                        name_painter.text(
                            egui::pos2(rect.left() + 14.0, rect.center().y),
                            Align2::LEFT_CENTER,
                            &entry.name,
                            FontId::proportional(14.0),
                            name_color,
                        );

                        painter.text(
                            egui::pos2(rect.left() + columns.bitrate_x, rect.center().y),
                            Align2::LEFT_CENTER,
                            entry.bitrate_text(),
                            FontId::proportional(12.5),
                            meta_color,
                        );

                        painter.text(
                            egui::pos2(rect.left() + columns.frequency_x, rect.center().y),
                            Align2::LEFT_CENTER,
                            entry.frequency_text(),
                            FontId::proportional(12.5),
                            meta_color,
                        );

                        let link_rect = painter.text(
                            egui::pos2(rect.left() + columns.link_x + 2.0, rect.center().y),
                            Align2::LEFT_CENTER,
                            "Open",
                            FontId::proportional(12.5),
                            link_color,
                        );
                        painter.line_segment(
                            [
                                egui::pos2(link_rect.left(), link_rect.bottom() + 1.0),
                                egui::pos2(link_rect.right(), link_rect.bottom() + 1.0),
                            ],
                            Stroke::new(1.0_f32, link_color),
                        );

                        if response.clicked() {
                            let clicked_pos = response
                                .interact_pointer_pos()
                                .or_else(|| response.hover_pos());
                            if clicked_pos
                                .map(|pos| link_area.contains(pos))
                                .unwrap_or(false)
                            {
                                clicked_link = Some(index);
                            } else {
                                clicked_row = Some(index);
                            }
                        }
                    }
                }
            });

        if let Some(index) = clicked_link {
            if let Some(entry) = self.library.get(index) {
                let path = entry.path.clone();

                let name = entry.name.clone();
                open_containing_folder(&path);
                self.set_status(
                    &format!("Opened the folder containing {name}."),
                    false,
                );
            }
        }
        if let Some(index) = clicked_row {
            self.select_and_play(index);
        }
    }

    fn empty_state_ui(&mut self, ui: &mut egui::Ui) {
        ui.add_space(70.0);
        ui.vertical_centered(|ui| {
            ui.label(
                RichText::new("No sounds loaded")
                    .size(22.0)
                    .strong()
                    .color(theme().text),
            );
            ui.add_space(6.0);
            ui.label(
                RichText::new("Add a folder and Sound Finder will scan it recursively.")
                    .size(13.5)
                    .color(theme().muted),
            );
            ui.add_space(16.0);
            if ui.button("Choose a folder...").clicked() {
                self.add_folder_dialog();
            }
            ui.add_space(18.0);
            ui.label(
                RichText::new("You can also drag a folder or sound files onto this window.")
                    .size(11.5)
                    .color(theme().dim),
            );
        });
    }

    fn no_matches_ui(&mut self, ui: &mut egui::Ui) {
        let query = self.search_query.trim().to_owned();
        ui.add_space(70.0);
        ui.vertical_centered(|ui| {
            ui.label(
                RichText::new(format!("No sounds match \"{query}\""))
                    .size(20.0)
                    .strong()
                    .color(theme().text),
            );
            ui.add_space(6.0);
            ui.label(
                RichText::new("Try another part of the sound name.")
                    .size(13.0)
                    .color(theme().muted),
            );
            ui.add_space(16.0);
            if ui.button("Clear search").clicked() {
                self.search_query.clear();
                self.search_focus = true;
            }
        });
    }

    fn loading_window(&mut self, ctx: &egui::Context) {
        if !self.loading {
            return;
        }

        let total = self.load_total;
        let done = self.load_done;
        let loaded = done.saturating_sub(self.load_failed);
        let remaining = total.saturating_sub(done);
        let skipped = self.load_failed;
        let progress = if total > 0 {
            done as f32 / total as f32
        } else {
            0.0
        };

        egui::Window::new("Importing sounds")
            .collapsible(false)
            .resizable(false)
            .anchor(egui::Align2::CENTER_CENTER, Vec2::new(0.0, -10.0))
            .default_width(340.0)
            .min_width(340.0)
            .max_width(340.0)
            .frame(
                egui::Frame::window(&ctx.style())
                    .fill(theme().player_bg)
                    .inner_margin(egui::Margin::same(16.0))
                    .rounding(10.0)
                    .stroke(Stroke::new(1.0_f32, theme().border)),
            )
            .show(ctx, |ui| {
                ui.horizontal(|ui| {
                    ui.add(egui::Spinner::new().size(17.0));
                    ui.label(
                        RichText::new("Scanning folders and decoding sounds...")
                            .size(12.5)
                            .color(theme().text),
                    );
                });

                ui.add_space(12.0);
                ui.add(
                    egui::ProgressBar::new(progress)
                        .desired_width(ui.available_width())
                        .show_percentage(),
                );
                ui.add_space(12.0);

                ui.horizontal(|ui| {
                    ui.vertical(|ui| {
                        ui.label(
                            RichText::new(loaded.to_string())
                                .size(25.0)
                                .strong()
                                .color(theme().accent),
                        );
                        ui.label(RichText::new("loaded").size(11.0).color(theme().muted));
                    });

                    ui.add_space(28.0);

                    ui.vertical(|ui| {
                        ui.label(
                            RichText::new(remaining.to_string())
                                .size(25.0)
                                .strong()
                                .color(theme().text),
                        );
                        ui.label(
                            RichText::new("still to load")
                                .size(11.0)
                                .color(theme().muted),
                        );
                    });

                    if skipped > 0 {
                        ui.add_space(28.0);
                        ui.vertical(|ui| {
                            ui.label(
                                RichText::new(skipped.to_string())
                                    .size(25.0)
                                    .strong()
                                    .color(theme().error),
                            );
                            ui.label(
                                RichText::new("skipped")
                                    .size(11.0)
                                    .color(theme().muted),
                            );
                        });
                    }
                });

                ui.add_space(14.0);
                if ui
                    .add_sized(
                        [ui.available_width(), 30.0],
                        egui::Button::new("Cancel import"),
                    )
                    .clicked()
                {
                    self.cancel_loading();
                }
            });
    }

    // -- settings / help / about --------------------------------------------

    fn settings_window(&mut self, ctx: &egui::Context) {
        let mut open = self.show_settings;
        egui::Window::new("Settings")
            .open(&mut open)
            .collapsible(false)
            .resizable(false)
            .default_width(300.0)
            .anchor(egui::Align2::RIGHT_TOP, Vec2::new(-18.0, 56.0))
            .show(ctx, |ui| {
                ui.label(
                    RichText::new("Appearance")
                        .size(13.0)
                        .strong()
                        .color(theme().text),
                );
                ui.add_space(6.0);
                ui.radio_value(&mut self.light_mode, false, "Dark mode");
                ui.radio_value(&mut self.light_mode, true, "Light mode");

                ui.add_space(10.0);
                ui.separator();
                ui.add_space(6.0);
                ui.label(
                    RichText::new("Learn more")
                        .size(13.0)
                        .strong()
                        .color(theme().text),
                );
                ui.add_space(6.0);
                if ui.button("Help...").clicked() {
                    self.show_help = true;
                }
                if ui.button("About Sound Finder...").clicked() {
                    self.show_about = true;
                }
            });
        self.show_settings = open;
    }

    fn help_window(&mut self, ctx: &egui::Context) {
        let mut open = self.show_help;
        egui::Window::new("Help")
            .open(&mut open)
            .collapsible(false)
            .resizable(true)
            .default_width(470.0)
            .anchor(egui::Align2::CENTER_CENTER, Vec2::ZERO)
            .show(ctx, |ui| {
                egui::ScrollArea::vertical()
                    .max_height(440.0)
                    .show(ui, |ui| {
                        ui.label(
                            RichText::new("Everything Sound Finder can do")
                                .size(15.0)
                                .strong()
                                .color(theme().text),
                        );
                        ui.add_space(10.0);
                        for (title, description) in HELP_ITEMS {
                            ui.label(
                                RichText::new(*title)
                                    .size(12.5)
                                    .strong()
                                    .color(theme().text),
                            );
                            ui.label(
                                RichText::new(*description)
                                    .size(11.5)
                                    .color(theme().muted),
                            );
                            ui.add_space(8.0);
                        }
                    });
            });
        self.show_help = open;
    }

    fn about_window(&mut self, ctx: &egui::Context) {
        let mut open = self.show_about;
        egui::Window::new("About Sound Finder")
            .open(&mut open)
            .collapsible(false)
            .resizable(false)
            .default_width(400.0)
            .anchor(egui::Align2::CENTER_CENTER, Vec2::ZERO)
            .show(ctx, |ui| {
                ui.vertical_centered(|ui| {
                    ui.label(
                        RichText::new("Sound Finder")
                            .font(FontId::new(30.0, title_family()))
                            .color(TITLE_COLOR),
                    );
                    ui.add_space(2.0);
                    ui.label(
                        RichText::new("A dark and light themed sound browser")
                            .size(12.0)
                            .color(theme().muted),
                    );
                    ui.add_space(16.0);
                    ui.label(
                        RichText::new(
                            "Made by Marc Urlus using Vibecoding and Deepseek 4.1 Flash. Version V0.8.3 nov 2026",
                        )
                        .size(13.0)
                        .color(theme().text),
                    );
                });
            });
        self.show_about = open;
    }

    fn player_ui(&mut self, ui: &mut egui::Ui) {
        let Some(index) = self.selected else {
            ui.add_space(36.0);
            ui.vertical_centered(|ui| {
                ui.label(
                    RichText::new("Select a sound to view its waveform")
                        .size(15.0)
                        .color(theme().muted),
                );
                ui.add_space(4.0);
                ui.label(
                    RichText::new("The playhead moves while the sound is playing.")
                        .size(11.5)
                        .color(theme().dim),
                );
                ui.add_space(3.0);
                ui.label(
                    RichText::new("Click or drag on the waveform to jump around.")
                        .size(11.5)
                        .color(theme().dim),
                );
            });
            return;
        };

        if index >= self.library.len() {
            self.selected = None;
            return;
        }

        if !self.text_input_focus
            && ui.input(|input| input.key_pressed(egui::Key::Space))
        {
            if self.playing == Some(index) {
                self.stop_playback();
                self.set_status("Playback stopped with the spacebar.", false);
            } else {
                self.start_playback(index);
                self.set_status("Playback started with the spacebar.", false);
            }
        }

        let Some(entry) = self.library.get(index) else {
            return;
        };

        let name = entry.name.clone();
        let name_limit = ((ui.available_width() - 360.0) / 8.0).max(12.0) as usize;
        let display_name = if name.len() > name_limit {
            format!("{}...", &name[0..name_limit])
        } else {
            name
        };
        let path = entry.path.clone();
        let details = entry.details_text();
        let duration = entry.duration_secs;
        let is_playing = self.playing == Some(index);
        let playhead = self.playhead;

        let mut replay = false;
        let mut stop = false;
        let mut deselect = false;
        let mut volume_changed = false;

        ui.horizontal(|ui| {
            ui.vertical(|ui| {
                ui.label(RichText::new(&display_name).size(16.0).strong().color(theme().text));
                ui.label(RichText::new(&details).size(11.5).color(theme().muted));
            });

            ui.horizontal_wrapped(|ui| {
                if ui
                    .add_enabled(self.playing.is_some(), egui::Button::new("Stop"))
                    .clicked()
                {
                    stop = true;
                }
                if ui
                    .button(if is_playing { "Restart" } else { "Play" })
                    .clicked()
                {
                    replay = true;
                }

                ui.add_space(10.0);
                ui.label(
                    RichText::new(format!(
                        "{} / {}",
                        format_time(playhead),
                        format_time(duration)
                    ))
                    .font(FontId::monospace(12.0))
                    .color(if is_playing { theme().accent } else { theme().muted }),
                );

                if ui
                    .button("Select range")
                    .on_hover_text("Click at In, drag to Out, then release")
                    .clicked()
                {
                    self.clear_range();
                    self.stop_playback();
                    self.range.selecting = true;
                    self.set_status(
                        "Selecting a range: click at In, drag to Out, then release.",
                        false,
                    );
                }

                if ui
                    .add_enabled(
                        self.range.active || self.range.selecting,
                        egui::Button::new("Clear range"),
                    )
                    .on_hover_text("Remove or cancel the range")
                    .clicked()
                {
                    self.stop_playback();
                    self.clear_range();
                    self.set_status("Range cleared.", false);
                }

                if self.range.active {
                    ui.label(
                        RichText::new(format!(
                            "In {} / Out {}",
                            format_time(self.range.range_start),
                            format_time(self.range.range_end)
                        ))
                        .font(FontId::monospace(10.5))
                        .color(theme().accent),
                    );
                }

                ui.horizontal(|ui| {
                    if ui
                        .add_enabled(
                            self.range.active,
                            egui::Button::new("In earlier")
                        )
                        .on_hover_text(
                            "Move the In point earlier, extending the selection"
                        )
                        .clicked()
                    {
                        self.move_range_in(-0.5);
                    }

                    if ui
                        .add_enabled(
                            self.range.active,
                            egui::Button::new("In later")
                        )
                        .on_hover_text(
                            "Move the In point later, retracting the selection"
                        )
                        .clicked()
                    {
                        self.move_range_in(0.5);
                    }
                });

                ui.add_space(6.0);

                ui.horizontal(|ui| {
                    if ui
                        .add_enabled(
                            self.range.active,
                            egui::Button::new("Out earlier")
                        )
                        .on_hover_text(
                            "Move the Out point earlier, retracting the selection"
                        )
                        .clicked()
                    {
                        self.move_range_out(-0.5);
                    }

                    if ui
                        .add_enabled(
                            self.range.active,
                            egui::Button::new("Out later")
                        )
                        .on_hover_text(
                            "Move the Out point later, extending the selection"
                        )
                        .clicked()
                    {
                        self.move_range_out(0.5);
                    }
                });

                if ui
                    .add_enabled(
                        self.range.active,
                        egui::Button::new("Save selection..."),
                    )
                    .on_hover_text("Save the In/Out excerpt as a WAV file")
                    .clicked()
                {
                    self.export_selection();
                }

                if ui
                    .button("Deselect")
                    .on_hover_text(path.display().to_string())
                    .clicked()
                {
                    deselect = true;
                }

                ui.add_space(12.0);
                let volume_response = ui.add_sized(
                    Vec2::new(90.0, 18.0),
                    egui::Slider::new(&mut self.volume, 0.0..=1.0)
                        .show_value(false),
                );
                if volume_response.changed() {
                    volume_changed = true;
                }
                ui.label(
                    RichText::new(format!(
                        "{}%",
                        (self.volume * 100.0).round() as i32
                    ))
                    .font(FontId::monospace(11.5))
                    .color(theme().muted),
                );
                ui.label(
                    RichText::new("Volume")
                        .size(11.5)
                        .color(theme().muted),
                );
            });
        });

        if volume_changed {
            self.apply_volume();
        }
        if replay {
            self.start_playback(index);
        }
        if stop {
            self.stop_playback();
        }
        if deselect {
            self.clear_selection();
            return;
        }

        ui.add_space(8.0);

        let entry = &self.library[index];
        let waveform = &entry.waveform;
        let height = (ui.available_height() - 2.0).max(70.0);
        let current_playhead = self.playhead;
        let current_is_playing = self.playing == Some(index);
        let was_range_active = self.range.active;
        let was_selecting = self.range.selecting;
        let seek_fraction =
            draw_waveform(
                ui,
                waveform,
                current_playhead,
                duration,
                current_is_playing,
                height,
                &mut self.range,
            );
        if self.range.active {
            let start = self.range.range_start;
            let end = self.range.range_end;
            if self.playhead < start || self.playhead > end {
                self.playhead = self.playhead.clamp(start, end);
                if self.playing == Some(index) {
                    self.seek_to(index, self.playhead);
                }
            }
        }
        if was_selecting && !self.range.selecting && !self.range.active {
            self.set_status(
                "Range not set; click and drag across the waveform first.",
                false,
            );
        }

        if !was_range_active && self.range.active {
            self.start_playback_at(index, self.range.range_start);
            self.set_status(
                &format!(
                    "Playing selection In {} / Out {}",
                    format_time(self.range.range_start),
                    format_time(self.range.range_end)
                ),
                false,
            );
        }

        if let Some(fraction) = seek_fraction {
            if !self.range.selecting {
                self.seek_to(index, fraction * duration);
            }
        }
    }
}

// ---------------------------------------------------------------------------
// eframe
// ---------------------------------------------------------------------------

impl eframe::App for SoundFinderApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        let applied_light = LIGHT_MODE.load(Ordering::Relaxed);
        if applied_light != self.light_mode {
            LIGHT_MODE.store(self.light_mode, Ordering::Relaxed);
            configure_style(ctx, self.light_mode);
            apply_titlebar(_frame, !self.light_mode);
        } else if !self.titlebar_styled {
            apply_titlebar(_frame, !self.light_mode);
        }
        self.titlebar_styled = true;

        self.poll_loading();
        self.tick();

        if !self.loading {
            let dropped: Vec<PathBuf> = ctx.input(|input| {
                input
                    .raw
                    .dropped_files
                    .iter()
                    .filter_map(|file| file.path.clone())
                    .collect()
            });
            if !dropped.is_empty() {
                let paths = collect_paths(dropped);
                if paths.is_empty() {
                    self.set_status("No supported audio files were dropped.", true);
                } else {
                    self.load_paths(paths);
                }
            }
        }

        egui::TopBottomPanel::top("toolbar")
            .frame(
                egui::Frame::none()
                    .fill(theme().toolbar_bg)
                    .inner_margin(egui::Margin::symmetric(16.0, 10.0)),
            )
            .show(ctx, |ui| {
                self.toolbar_ui(ui);
            });

        egui::TopBottomPanel::bottom("player")
            .exact_height(206.0)
            .frame(
                egui::Frame::none()
                    .fill(theme().player_bg)
                    .inner_margin(egui::Margin::symmetric(16.0, 12.0)),
            )
            .show(ctx, |ui| {
                let rect = ui.max_rect();
                ui.painter().line_segment(
                    [
                        egui::pos2(rect.left(), rect.top()),
                        egui::pos2(rect.right(), rect.top()),
                    ],
                    Stroke::new(1.0_f32, theme().border),
                );
                self.player_ui(ui);
            });

        egui::CentralPanel::default()
            .frame(
                egui::Frame::none()
                    .fill(theme().bg)
                    .inner_margin(egui::Margin::symmetric(16.0, 0.0)),
            )
            .show(ctx, |ui| {
                self.table_ui(ui);
            });

        self.loading_window(ctx);
        self.settings_window(ctx);
        self.help_window(ctx);
        self.about_window(ctx);

        if self.playing.is_some() {
            ctx.request_repaint_after(Duration::from_millis(16));
        } else if self.loading {
            ctx.request_repaint_after(Duration::from_millis(80));
        }
    }
}

// ---------------------------------------------------------------------------
// Painting helpers
// ---------------------------------------------------------------------------

struct Columns {
    bitrate_x: f32,
    frequency_x: f32,
    link_x: f32,
}

impl Columns {
    fn new(width: f32) -> Self {
        let link_x = (width - LINK_WIDTH).max(0.0);
        let frequency_x = (link_x - FREQUENCY_WIDTH).max(0.0);
        let bitrate_x = (frequency_x - BITRATE_WIDTH).max(0.0);
        Self {
            bitrate_x,
            frequency_x,
            link_x,
        }
    }
}

fn gear_button(ui: &mut egui::Ui) -> egui::Response {
    let (rect, response) =
        ui.allocate_exact_size(Vec2::splat(30.0), Sense::click());
    let response = response
        .on_hover_cursor(egui::CursorIcon::PointingHand)
        .on_hover_text("Settings: appearance, Help and About");
    let p = theme();

    let background = if response.is_pointer_button_down_on() {
        p.widget_active_bg
    } else if response.hovered() {
        p.widget_hover_bg
    } else {
        Color32::TRANSPARENT
    };
    if background != Color32::TRANSPARENT {
        ui.painter().rect_filled(rect.shrink(1.0), 6.0, background);
    }

    let center = rect.center();
    let painter = ui.painter();
    let color = GEAR_COLOR;
    let body_radius = 5.8;
    let tooth_inner = body_radius - 0.5;
    let tooth_outer = 8.6;
    for tooth in 0..8 {
        let angle = tooth as f32 * std::f32::consts::TAU / 8.0;
        let direction = Vec2::new(angle.cos(), angle.sin());
        painter.line_segment(
            [
                center + direction * tooth_inner,
                center + direction * tooth_outer,
            ],
            Stroke::new(2.6_f32, color),
        );
    }
    painter.circle_stroke(center, body_radius, Stroke::new(2.0_f32, color));
    painter.circle_filled(center, 2.2, color);

    response
}

fn search_button(ui: &mut egui::Ui, active: bool) -> egui::Response {
    let (rect, response) =
        ui.allocate_exact_size(Vec2::splat(30.0), Sense::click());
    let response = response
        .on_hover_cursor(egui::CursorIcon::PointingHand)
        .on_hover_text("Search sounds by name");
    let p = theme();

    let background = if active || response.is_pointer_button_down_on() {
        p.widget_active_bg
    } else if response.hovered() {
        p.widget_hover_bg
    } else {
        Color32::TRANSPARENT
    };
    if background != Color32::TRANSPARENT {
        ui.painter().rect_filled(rect.shrink(1.0), 6.0, background);
    }

    let center = rect.center();
    let painter = ui.painter();
    let color = p.text;
    let glass_center = center + Vec2::new(-1.5, -1.5);
    painter.circle_stroke(glass_center, 5.2, Stroke::new(2.0_f32, color));
    painter.line_segment(
        [
            glass_center + Vec2::new(3.7, 3.7),
            center + Vec2::new(7.2, 7.2),
        ],
        Stroke::new(2.4_f32, color),
    );

    response
}

fn search_clear_button(ui: &mut egui::Ui, enabled: bool) -> egui::Response {
    let (rect, response) =
        ui.allocate_exact_size(Vec2::splat(24.0), Sense::click());
    let response = if enabled {
        response
            .on_hover_cursor(egui::CursorIcon::PointingHand)
            .on_hover_text("Clear the search and show all sounds")
    } else {
        response.on_hover_text("The search box is already empty")
    };
    let p = theme();

    if enabled {
        let background = if response.is_pointer_button_down_on() {
            p.widget_active_bg
        } else if response.hovered() {
            p.widget_hover_bg
        } else {
            Color32::TRANSPARENT
        };
        if background != Color32::TRANSPARENT {
            ui.painter().rect_filled(rect.shrink(1.0), 6.0, background);
        }
    }

    let center = rect.center();
    let color = if enabled { p.text } else { p.dim };
    let d = 4.2;
    ui.painter().line_segment(
        [
            center + Vec2::new(-d, -d),
            center + Vec2::new(d, d),
        ],
        Stroke::new(2.0_f32, color),
    );
    ui.painter().line_segment(
        [
            center + Vec2::new(-d, d),
            center + Vec2::new(d, -d),
        ],
        Stroke::new(2.0_f32, color),
    );

    response
}

fn draw_header(ui: &mut egui::Ui, width: f32) {
    let (rect, _) =
        ui.allocate_exact_size(Vec2::new(width, HEADER_HEIGHT), Sense::hover());

    let painter = ui.painter();
    painter.rect_filled(rect, 0.0, theme().header_bg);
    painter.line_segment(
        [
            egui::pos2(rect.left(), rect.bottom() - 0.5),
            egui::pos2(rect.right(), rect.bottom() - 0.5),
        ],
        Stroke::new(1.0_f32, theme().border),
    );

    let columns = Columns::new(rect.width());
    let font = FontId::proportional(11.0);

    painter.text(
        egui::pos2(rect.left() + 14.0, rect.center().y),
        Align2::LEFT_CENTER,
        "NAME",
        font.clone(),
        theme().muted,
    );
    painter.text(
        egui::pos2(rect.left() + columns.bitrate_x, rect.center().y),
        Align2::LEFT_CENTER,
        "BIT RATE",
        font.clone(),
        theme().muted,
    );
    painter.text(
        egui::pos2(rect.left() + columns.frequency_x, rect.center().y),
        Align2::LEFT_CENTER,
        "FREQUENCY",
        font.clone(),
        theme().muted,
    );
    painter.text(
        egui::pos2(rect.left() + columns.link_x + 2.0, rect.center().y),
        Align2::LEFT_CENTER,
        "FILE",
        font,
        theme().muted,
    );

    ui.add_space(2.0);
}

/// Draws the waveform and returns the requested playhead fraction when the
/// user clicks or drags on it.
fn draw_waveform(
    ui: &mut egui::Ui,
    waveform: &[f32],
    playhead: f32,
    duration: f32,
    is_playing: bool,
    height: f32,
    range: &mut RangeState,
) -> Option<f32> {
    let (response, painter) = ui.allocate_painter(
        Vec2::new(ui.available_width(), height),
        Sense::click_and_drag(),
    );
    let mut endpoint_dragged = false;
    let response = response.on_hover_cursor(egui::CursorIcon::ResizeHorizontal);
    let rect = response.rect;

    painter.rect_filled(rect, 6.0, theme().wave_bg);
    painter.rect_stroke(rect, 6.0, Stroke::new(1.0_f32, theme().border));

    let inner = rect.shrink2(Vec2::new(12.0, 10.0));
    if inner.width() <= 0.0 || inner.height() <= 0.0 {
        return None;
    }

    let hover_fraction = response
        .hover_pos()
        .map(|pos| ((pos.x - inner.left()) / inner.width()).clamp(0.0, 1.0));

    // Zero line.
    painter.line_segment(
        [
            egui::pos2(inner.left(), inner.center().y),
            egui::pos2(inner.right(), inner.center().y),
        ],
        Stroke::new(1.0_f32, theme().wave_zero),
    );

    if waveform.is_empty() {
        painter.text(
            rect.center(),
            Align2::CENTER_CENTER,
            "Waveform unavailable",
            FontId::proportional(12.0),
            theme().dim,
        );
        return None;
    }

    let peak = waveform
        .iter()
        .copied()
        .fold(0.0_f32, f32::max)
        .max(1.0e-6);
    let amplitude = inner.height() * 0.46;
    let count = waveform.len();
    let step = inner.width() / count as f32;
    let bar_stroke = (step * 0.9).max(1.0);
    let playhead_fraction = if duration > 0.0 {
        (playhead / duration).clamp(0.0, 1.0)
    } else {
        0.0
    };

    if range.selecting {
        if response.is_pointer_button_down_on() {
            let fraction = response
                .interact_pointer_pos()
                .map(|pos| ((pos.x - inner.left()) / inner.width()).clamp(0.0, 1.0));
            if let Some(fraction) = fraction {
                if !range.dragging {
                    range.drag_in = fraction;
                    range.drag_out = fraction;
                    range.dragging = true;
                } else {
                    range.drag_out = fraction;
                }
            }
        } else if range.dragging {
            let in_fraction = range.drag_in.min(range.drag_out);
            let out_fraction = range.drag_in.max(range.drag_out);
            if duration > 0.0 && out_fraction - in_fraction > 0.0005 {
                range.range_start = in_fraction * duration;
                range.range_end = out_fraction * duration;
                range.active = true;
            }
            range.dragging = false;
            range.selecting = false;
        }
    }

    if range.active && duration > 0.0
        && (response.clicked() || response.is_pointer_button_down_on()) {
        let fraction = response
            .interact_pointer_pos()
            .map(|pos| ((pos.x - inner.left()) / inner.width()).clamp(0.0, 1.0));

        if let Some(fraction) = fraction {
            let in_fraction = (range.range_start / duration).clamp(0.0, 1.0);
            let out_fraction = (range.range_end / duration).clamp(0.0, 1.0);
            let in_distance = (fraction - in_fraction).abs() * inner.width();
            let out_distance = (fraction - out_fraction).abs() * inner.width();
            let hit_slop = 14.0;

            if in_distance <= hit_slop && in_distance <= out_distance {
                if range.range_end - range.range_start > 0.02 {
                    let max_start = range.range_end - 0.02;
                    range.range_start =
                        (fraction * duration).clamp(0.0, max_start);
                    endpoint_dragged = true;
                }
            } else if out_distance <= hit_slop {
                if range.range_end - range.range_start > 0.02 {
                    let min_end = range.range_start + 0.02;
                    range.range_end =
                        (fraction * duration).clamp(min_end, duration);
                    endpoint_dragged = true;
                }
            }
        }
    }

    let selection_in = if range.active && duration > 0.0 {
        (range.range_start / duration).clamp(0.0, 1.0)
    } else if range.dragging {
        range.drag_in.min(range.drag_out)
    } else {
        -1.0
    };
    let selection_out = if range.active && duration > 0.0 {
        (range.range_end / duration).clamp(0.0, 1.0)
    } else if range.dragging {
        range.drag_in.max(range.drag_out)
    } else {
        -1.0
    };
    let has_selection = selection_in >= 0.0 && selection_out >= 0.0;

    let wave_painter = painter.with_clip_rect(inner);
    for (index, value) in waveform.iter().enumerate() {
        let x = inner.left() + (index as f32 + 0.5) * step;
        let bar_height =
            ((value / peak).clamp(0.0, 1.0) * amplitude).max(1.0);
        let fraction = index as f32 / count as f32;
        let in_selection =
            has_selection && fraction >= selection_in && fraction <= selection_out;
        let color = if in_selection {
            theme().accent
        } else if playhead_fraction > 0.0 && fraction <= playhead_fraction {
            theme().wave_played
        } else {
            theme().wave
        };
        wave_painter.line_segment(
            [
                egui::pos2(x, inner.center().y - bar_height),
                egui::pos2(x, inner.center().y + bar_height),
            ],
            Stroke::new(bar_stroke, color),
        );
    }

    if has_selection {
        let x_in = inner.left() + selection_in.clamp(0.0, 1.0) * inner.width();
        let x_out = inner.left() + selection_out.clamp(0.0, 1.0) * inner.width();
        let selection_color = theme().accent;
        let bracket_y = inner.top() - 8.0;

        painter.line_segment(
            [
                egui::pos2(x_in, inner.top()),
                egui::pos2(x_in, inner.bottom()),
            ],
            Stroke::new(2.5_f32, selection_color),
        );
        painter.line_segment(
            [
                egui::pos2(x_out, inner.top()),
                egui::pos2(x_out, inner.bottom()),
            ],
            Stroke::new(2.5_f32, selection_color),
        );
        painter.line_segment(
            [
                egui::pos2(x_in, bracket_y),
                egui::pos2(x_out, bracket_y),
            ],
            Stroke::new(2.0_f32, selection_color),
        );
    }

    // Scrub hint: a faint line where a click would move the playhead.
    if !response.is_pointer_button_down_on() {
        if let Some(fraction) = hover_fraction {
            let hover_x = inner.left() + fraction * inner.width();
            painter.line_segment(
                [
                    egui::pos2(hover_x, inner.top()),
                    egui::pos2(hover_x, inner.bottom()),
                ],
                Stroke::new(1.0_f32, theme().scrub_hint),
            );
        }
    }

    // Playhead (four times the original size).
    let x = inner.left() + playhead_fraction * inner.width();
    let playhead_color = theme().playhead;
    painter.line_segment(
        [
            egui::pos2(x, inner.top() - 16.0),
            egui::pos2(x, inner.bottom() + 16.0),
        ],
        Stroke::new(14.0_f32, playhead_color),
    );
    if is_playing || response.is_pointer_button_down_on() {
        painter.circle_filled(egui::pos2(x, inner.top() - 20.0), 24.0, playhead_color);
    }

    if endpoint_dragged {
        None
    } else if response.is_pointer_button_down_on() || response.clicked() {
        response.interact_pointer_pos().map(|pos| {
            ((pos.x - inner.left()) / inner.width()).clamp(0.0, 1.0)
        })
    } else {
        None
    }
}

// ---------------------------------------------------------------------------
// File discovery + decoding
// ---------------------------------------------------------------------------

fn is_audio_file(path: &Path) -> bool {
    path.extension()
        .and_then(|ext| ext.to_str())
        .map(|ext| {
            AUDIO_EXTENSIONS
                .iter()
                .any(|allowed| ext.eq_ignore_ascii_case(allowed))
        })
        .unwrap_or(false)
}

fn collect_audio_files(folder: &Path) -> Vec<PathBuf> {
    let mut paths: Vec<PathBuf> = WalkDir::new(folder)
        .follow_links(false)
        .into_iter()
        .filter_map(Result::ok)
        .filter(|entry| entry.file_type().is_file())
        .map(|entry| entry.into_path())
        .filter(|path| is_audio_file(path))
        .map(|path| fs::canonicalize(&path).unwrap_or_else(|_| path.to_path_buf()))
        .collect();
    paths.sort();
    paths
}

fn collect_paths(paths: Vec<PathBuf>) -> Vec<PathBuf> {
    let mut out = Vec::new();
    for path in paths {
        if path.is_dir() {
            out.extend(collect_audio_files(&path));
        } else if is_audio_file(&path) {
            out.push(fs::canonicalize(&path).unwrap_or_else(|_| path.to_path_buf()));
        }
    }
    out.sort();
    out
}

/// Opens the folder that contains `path` and selects the file in it.
fn open_containing_folder(path: &Path) {
    #[cfg(target_os = "windows")]
    {
        use std::os::windows::process::CommandExt;

        // Explorer expects the comma to touch the quoted path: /select,"C:\dir\file.wav".
        // `raw_arg` keeps that exact form; `arg` would re-quote the whole switch.
        let _ = std::process::Command::new("explorer")
            .raw_arg(format!("/select,\"{}\"", path.display()))
            .spawn();
    }
    #[cfg(target_os = "macos")]
    {
        let _ = std::process::Command::new("open")
            .arg("-R")
            .arg(path)
            .spawn();
    }
    #[cfg(all(unix, not(target_os = "macos")))]
    {
        if let Some(parent) = path.parent() {
            let _ = std::process::Command::new("xdg-open").arg(parent).spawn();
        }
    }
}

fn path_key(path: &Path) -> String {
    let mut canonical = fs::canonicalize(path)
        .unwrap_or_else(|_| path.to_path_buf())
        .to_string_lossy()
        .to_string();
    #[cfg(target_os = "windows")]
    {
        canonical = canonical.to_lowercase();
    }
    canonical
}

/// Location of the file that remembers the loaded sound paths between runs.
fn library_state_path() -> Option<PathBuf> {
    if let Some(appdata) = std::env::var_os("APPDATA") {
        return Some(
            PathBuf::from(appdata)
                .join("SoundFinder")
                .join("library.txt"),
        );
    }
    if let Some(home) = std::env::var_os("HOME") {
        return Some(
            PathBuf::from(home)
                .join(".config")
                .join("soundfinder")
                .join("library.txt"),
        );
    }
    None
}

/// Reads the paths saved by a previous run, skipping files that no longer exist.
fn load_saved_library() -> Vec<PathBuf> {
    let Some(path) = library_state_path() else {
        return Vec::new();
    };
    let Ok(contents) = fs::read_to_string(&path) else {
        return Vec::new();
    };
    contents
        .lines()
        .map(str::trim)
        .filter(|line| !line.is_empty())
        .map(PathBuf::from)
        .filter(|path| path.is_file() && is_audio_file(path))
        .map(|path| fs::canonicalize(&path).unwrap_or_else(|_| path.to_path_buf()))
        .collect()
}

fn decode_entry(path: &Path) -> Result<SoundEntry, String> {
    let name = path
        .file_name()
        .and_then(|name| name.to_str())
        .unwrap_or("sound")
        .to_owned();

    let file = File::open(path).map_err(|err| err.to_string())?;
    let decoder = Decoder::new(BufReader::new(file)).map_err(|err| err.to_string())?;

    let sample_rate = decoder.sample_rate();
    let channels = decoder.channels().max(1) as usize;

    let mut peaks: Vec<f32> = Vec::new();
    let mut block_peak = 0.0_f32;
    let mut frames_in_block = 0_u32;
    let mut channel_position = 0_usize;
    let mut total_frames = 0_u64;

    for sample in decoder {
        let value = (sample as f32 / 32768.0).abs();
        if value > block_peak {
            block_peak = value;
        }

        channel_position += 1;
        if channel_position >= channels {
            channel_position = 0;
            total_frames += 1;
            frames_in_block += 1;
            if frames_in_block >= 64 {
                peaks.push(block_peak);
                block_peak = 0.0;
                frames_in_block = 0;
            }
        }
    }
    if frames_in_block > 0 {
        peaks.push(block_peak);
    }

    let duration_secs = if sample_rate > 0 {
        total_frames as f32 / sample_rate as f32
    } else {
        0.0
    };

    let is_wav = path
        .extension()
        .and_then(|ext| ext.to_str())
        .map(|ext| ext.eq_ignore_ascii_case("wav"))
        .unwrap_or(false);

    let bitrate_kbps = if is_wav {
        wav_bitrate_kbps(path).unwrap_or_else(|| average_bitrate_kbps(path, duration_secs))
    } else {
        average_bitrate_kbps(path, duration_secs)
    };

    Ok(SoundEntry {
        name,
        path: path.to_path_buf(),
        sample_rate,
        channels: channels as u16,
        bitrate_kbps,
        duration_secs,
        waveform: downsample(&peaks, WAVEFORM_POINTS),
    })
}

fn downsample(peaks: &[f32], target: usize) -> Vec<f32> {
    if peaks.len() <= target {
        return peaks.to_vec();
    }

    let mut out = Vec::with_capacity(target);
    for index in 0..target {
        let start = index * peaks.len() / target;
        let end = ((index + 1) * peaks.len() / target).max(start + 1);
        let peak = peaks[start..end]
            .iter()
            .copied()
            .fold(0.0_f32, f32::max);
        out.push(peak);
    }
    out
}

fn average_bitrate_kbps(path: &Path, duration_secs: f32) -> u32 {
    if duration_secs <= 0.0 {
        return 0;
    }
    match fs::metadata(path) {
        Ok(metadata) => {
            let bits = metadata.len() as f64 * 8.0;
            (bits / duration_secs as f64 / 1000.0).round() as u32
        }
        Err(_) => 0,
    }
}

/// Reads the byte rate from a PCM WAV header so the bit rate is exact even
/// for very short files where the container overhead would skew the average.
fn wav_bitrate_kbps(path: &Path) -> Option<u32> {
    let mut file = File::open(path).ok()?;
    let mut riff = [0_u8; 12];
    file.read_exact(&mut riff).ok()?;
    if &riff[0..4] != b"RIFF" || &riff[8..12] != b"WAVE" {
        return None;
    }

    loop {
        let mut header = [0_u8; 8];
        file.read_exact(&mut header).ok()?;
        let id = &header[0..4];
        let size = u32::from_le_bytes([header[4], header[5], header[6], header[7]])
            as usize;

        if id == b"fmt " {
            let mut format = vec![0_u8; size.min(64)];
            file.read_exact(&mut format).ok()?;
            if format.len() >= 12 {
                let byte_rate = u32::from_le_bytes([
                    format[8],
                    format[9],
                    format[10],
                    format[11],
                ]);
                if byte_rate == 0 {
                    return None;
                }
                return Some(byte_rate.saturating_mul(8) / 1000);
            }
            return None;
        }

        file.seek(SeekFrom::Current(
            size as i64 + (size & 1) as i64,
        ))
        .ok()?;
    }
}

// ---------------------------------------------------------------------------
// Formatting
// ---------------------------------------------------------------------------

fn format_time(seconds: f32) -> String {
    let seconds = seconds.max(0.0);
    let total_tenths = (seconds * 10.0).round() as u64;
    let tenths = total_tenths % 10;
    let total_seconds = total_tenths / 10;
    let secs = total_seconds % 60;
    let mins = (total_seconds / 60) % 60;
    let hours = total_seconds / 3600;

    if hours > 0 {
        format!("{hours}:{mins:02}:{secs:02}")
    } else {
        format!("{mins}:{secs:02}.{tenths}")
    }
}

fn append_u16_le(bytes: &mut Vec<u8>, value: u16) {
    bytes.push((value & 0xFF) as u8);
    bytes.push((value >> 8) as u8);
}

fn append_u32_le(bytes: &mut Vec<u8>, value: u32) {
    bytes.push((value & 0xFF) as u8);
    bytes.push(((value >> 8) & 0xFF) as u8);
    bytes.push(((value >> 16) & 0xFF) as u8);
    bytes.push((value >> 24) as u8);
}

fn append_ascii(bytes: &mut Vec<u8>, text: &str) {
    for ch in text.bytes() {
        bytes.push(ch);
    }
}

// ---------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------

#[cfg(target_os = "windows")]
fn apply_titlebar(frame: &eframe::Frame, dark: bool) {
    use raw_window_handle::{HasWindowHandle, RawWindowHandle};

    let Ok(handle) = frame.window_handle() else {
        return;
    };
    let RawWindowHandle::Win32(window) = handle.as_raw() else {
        return;
    };

    #[link(name = "dwmapi")]
    extern "system" {
        fn DwmSetWindowAttribute(
            hwnd: *mut core::ffi::c_void,
            attribute: u32,
            value: *const core::ffi::c_void,
            size: u32,
        ) -> i32;
    }

    let hwnd = window.hwnd.get() as *mut core::ffi::c_void;
    let enabled: i32 = if dark { 1 } else { 0 };
    let value = &enabled as *const i32 as *const core::ffi::c_void;
    let size = std::mem::size_of::<i32>() as u32;

    unsafe {
        // 20 works on Windows 10 20H1+ and Windows 11; 19 covers older Win10.
        if DwmSetWindowAttribute(hwnd, 20, value, size) != 0 {
            let _ = DwmSetWindowAttribute(hwnd, 19, value, size);
        }
    }
}

#[cfg(not(target_os = "windows"))]
fn apply_titlebar(_frame: &eframe::Frame, _dark: bool) {}

fn title_family() -> FontFamily {
    FontFamily::Name("Herkules".into())
}

fn configure_style(ctx: &egui::Context, light: bool) {
    let mut fonts = egui::FontDefinitions::default();
    fonts.font_data.insert(
        "Herkules".to_owned(),
        egui::FontData::from_static(include_bytes!("../assets/Herkules.ttf")),
    );
    fonts
        .families
        .insert(title_family(), vec!["Herkules".to_owned()]);
    ctx.set_fonts(fonts);

    ctx.set_visuals_of(egui::Theme::Dark, style_visuals(Palette::DARK, false));
    ctx.set_visuals_of(egui::Theme::Light, style_visuals(Palette::LIGHT, true));
    ctx.set_theme(if light {
        egui::Theme::Light
    } else {
        egui::Theme::Dark
    });

    ctx.all_styles_mut(|style| {
        style.spacing.item_spacing = Vec2::new(8.0, 6.0);
        style.spacing.button_padding = Vec2::new(10.0, 6.0);
    });
}

fn style_visuals(p: Palette, light: bool) -> egui::Visuals {
    let mut visuals = if light {
        egui::Visuals::light()
    } else {
        egui::Visuals::dark()
    };
    visuals.panel_fill = p.bg;
    visuals.window_fill = p.player_bg;
    visuals.extreme_bg_color = p.extreme_bg;
    visuals.faint_bg_color = p.header_bg;
    visuals.override_text_color = Some(p.text);
    visuals.hyperlink_color = p.accent;
    visuals.selection.bg_fill = p.selected_bg;
    visuals.selection.stroke = Stroke::new(1.0_f32, p.text);
    visuals.widgets.noninteractive.bg_fill = p.header_bg;
    visuals.widgets.noninteractive.weak_bg_fill = p.header_bg;
    visuals.widgets.inactive.bg_fill = p.widget_bg;
    visuals.widgets.inactive.weak_bg_fill = p.widget_weak;
    visuals.widgets.hovered.bg_fill = p.widget_hover_bg;
    visuals.widgets.hovered.weak_bg_fill = p.widget_hover_weak;
    visuals.widgets.active.bg_fill = p.widget_active_bg;
    visuals.widgets.active.weak_bg_fill = p.widget_active_weak;
    visuals
}

fn main() -> eframe::Result {
    let initial = collect_paths(std::env::args().skip(1).map(PathBuf::from).collect());

    let icon = eframe::icon_data::from_png_bytes(include_bytes!(
        "../assets/soundfinder_256.png"
    ))
    .unwrap_or_default();

    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_title("Sound Finder v0.8.3")
            .with_app_id("SoundFinder")
            .with_icon(icon)
            .with_inner_size([1080.0, 760.0])
            .with_min_inner_size([760.0, 520.0]),
        ..Default::default()
    };

    eframe::run_native(
        "Sound Finder v0.8.3",
        options,
        Box::new(move |cc| {
            configure_style(&cc.egui_ctx, false);
            Ok(Box::new(SoundFinderApp::new(initial)))
        }),
    )
}